# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'QT_interface.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1137, 551)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.outputField = QtWidgets.QTextBrowser(self.centralwidget)
        self.outputField.setGeometry(QtCore.QRect(390, 50, 731, 371))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        self.outputField.setFont(font)
        self.outputField.setObjectName("outputField")
        self.complyBtn = QtWidgets.QPushButton(self.centralwidget)
        self.complyBtn.setGeometry(QtCore.QRect(390, 450, 101, 41))
        self.complyBtn.setObjectName("complyBtn")
        self.queryGenerationField = QtWidgets.QTextEdit(self.centralwidget)
        self.queryGenerationField.setGeometry(QtCore.QRect(10, 50, 351, 371))
        font = QtGui.QFont()
        font.setFamily("Times New Roman")
        self.queryGenerationField.setFont(font)
        self.queryGenerationField.setObjectName("queryGenerationField")
        self.tableNameField = QtWidgets.QLineEdit(self.centralwidget)
        self.tableNameField.setGeometry(QtCore.QRect(170, 470, 191, 21))
        self.tableNameField.setObjectName("tableNameField")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(180, 440, 181, 21))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(10, 10, 341, 31))
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(590, 10, 341, 31))
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1137, 22))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        self.scriptsMenu = QtWidgets.QMenu(self.menu)
        self.scriptsMenu.setObjectName("scriptsMenu")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.outputScriptBtn = QtWidgets.QAction(MainWindow)
        self.outputScriptBtn.setObjectName("outputScriptBtn")
        self.clearOutpFieldBtn = QtWidgets.QAction(MainWindow)
        self.clearOutpFieldBtn.setObjectName("clearOutpFieldBtn")
        self.barcdMakeBtn = QtWidgets.QAction(MainWindow)
        self.barcdMakeBtn.setObjectName("barcdMakeBtn")
        self.scriptsMenu.addAction(self.outputScriptBtn)
        self.scriptsMenu.addAction(self.barcdMakeBtn)
        self.menu.addAction(self.scriptsMenu.menuAction())
        self.menu.addAction(self.clearOutpFieldBtn)
        self.menubar.addAction(self.menu.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.complyBtn.setText(_translate("MainWindow", "Выполнить"))
        self.label.setText(_translate("MainWindow", "Введите <имя_таблицы>"))
        self.label_2.setText(_translate("MainWindow", "Поле формирования запросов к таблице"))
        self.label_3.setText(_translate("MainWindow", "Поле вывода информации"))
        self.menu.setTitle(_translate("MainWindow", "Меню"))
        self.scriptsMenu.setTitle(_translate("MainWindow", "Готовые скрипты"))
        self.outputScriptBtn.setText(_translate("MainWindow", "Вывести все из <имя_таблицы>"))
        self.clearOutpFieldBtn.setText(_translate("MainWindow", "Очистить поле вывода"))
        self.barcdMakeBtn.setText(_translate("MainWindow", "Создать штрих-код(ы)"))
