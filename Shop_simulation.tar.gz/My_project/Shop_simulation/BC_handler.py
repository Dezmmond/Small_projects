#!-*- coding: utf-8 -*-
#!/usr/bin/python3

# This module is the handler for making bar code.
# It contains just functions for converting decimal numbers to binary.

# Этот модуль является обработчиком для создания штрих-кода.
# В нем содержатся только функции для преобразования десятичных чисел в двоичные.

class BarCode_maker:
    def __init__(self, code):
        self.l_code = code[0:6]
        self.r_code = code[6:12]
        self.result = [['101']]

    def l_bin_hndl(self):
        l_side = []
        for var in self.l_code:
            var = int(var)
            binar = ""
            while var != 0:
                if var % 2 == 1:
                    binar += "1"
                    var = var // 2
                else:
                    binar += "0"
                    var = var // 2
            if len(binar) < 5:
                dop = (5 - len(binar)) * "0"
                l_side.append(dop + binar[::-1])
            else: # as a precaution
                l_side.append(binar[::-1])

        return l_side
  
    def r_bin_hndl(self):
        r_side = []
        for var in self.r_code:
            var = int(var)
            binar = ""
            while var != 0:
                if var % 2 == 1:
                    binar += "1"
                    var = var // 2
                else:
                    binar += "0"
                    var = var // 2
            if len(binar) < 5:
                dop = ((5 - len(binar)) - 1) * "0"
                r_side.append("1" + dop + binar[::-1])
            else: # as a precaution
                r_side.append(binar[::-1])

        return r_side

    def for_print(self):
        out = ""
        self.result.append(self.l_bin_hndl())
        self.result.append(['01010'])
        self.result.append(self.r_bin_hndl())
        self.result.append(['101'])
        for tup in self.result:
            for n in tup:
                out += n
        return out


# code = "957000163253"
# a = BarCode_maker(code)
# print(a.for_print())
