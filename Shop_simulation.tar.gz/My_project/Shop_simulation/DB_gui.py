#!-*- coding: utf-8 -*-
#!/usr/bin/python3

# This module is the node for the rest of the application modules.
# It contains the basic scripts and methods of interaction with QT-application.

# Этот модуль является узловым для остальных модулей приложения.
# В нем содержатся основные скрипты и методы взаимодействия с QT-приложением.

import sys
from PyQt5 import QtWidgets
import QT_interface
import DB_connect
import DB_scripts


class MyGui(QtWidgets.QMainWindow, QT_interface.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.complyBtn.clicked.connect(self.done)
        self.clearOutpFieldBtn.triggered.connect(self.clear_field)
        self.outputScriptBtn.triggered.connect(self.show_all)
        self.barcdMakeBtn.triggered.connect(self.make_barcode)
        self.table_name = ""
        self.txt_get = ""
        self.txt_out = ""

    def done(self):
        self.txt_get = self.queryGenerationField.toPlainText()
        self.txt_out = DB_connect.pg_connect(self.txt_get)
        self.outputField.setText(self.txt_out)

    def clear_field(self):
        self.outputField.setText("")

    def show_all(self):
        self.table_name = self.tableNameField.text()
        self.txt_out = DB_scripts.show_all(self.table_name)
        self.outputField.setText(self.txt_out)

    def make_barcode(self):
        if self.txt_out == "":
            raise ImportError
        else:
            DB_scripts.make_bc(self.txt_out)


def main():
    app = QtWidgets.QApplication(sys.argv)
    window = MyGui()
    window.show()
    app.exec_()


if __name__ == "__main__":
    main()
