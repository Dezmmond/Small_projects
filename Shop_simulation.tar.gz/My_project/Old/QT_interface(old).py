# -*- coding: utf-8 -*-

from tkinter import *
import DB_connect as connect
import DB_scripts as scripts

class Handler_int():
    def __init__(self, *args, **kwargs):

        self.l1 = Label(root, text = "Введите имя таблицы:")
        self.l1.place(x = 5, y = 457)

        self.l2 = Label(root, text = "Список стандартных запросов", font = "Arial 14")
        self.l2.place(x = 870, y = 5)

        self.but = Button(root, text = "Выполнить",
                     width = 15, height = 2)
        self.but.bind('<Button-1>', self.done)
        self.but.place(x = 500, y = 450)

        self.clrbut = Button(root, text = "Удалить информацию",
                     width = 17, height = 2)
        self.clrbut.bind('<Button-1>', self.clr)
        self.clrbut.place(x = 630, y = 450)

        self.selctbut = Button(root, text = "Показать все из таблицы <имя_таблицы>",
                     width = 32, height = 2)
        self.selctbut.bind('<Button-1>', self.scrp)
        self.selctbut.place(x = 885, y = 35)

        self.txtinp = Text(root, width = 40,
                        font = "Consoals 12",
                        wrap = WORD)
        self.txtinp.place(x = 5, y = 5)
        
        self.txtout = Text(root, width = 40, 
                           font = "Consoals 12", 
                           wrap = WORD, state = DISABLED)
        self.txtout.place(x = 400, y = 5)

        self.request = StringVar()

        self.poleinp = Entry(root, width = 38)
        self.poleinp.place(x = 135, y = 460)

    def done(self, *args):
        self.request = self.txtinp.get(1.0, END)
        self.request = self.request
        self.records = connect.pg_connect(self.request)
        self.txtout.configure(state = NORMAL)
        self.txtout.insert(1.0, self.records)
        self.txtout.configure(state = DISABLED)  

    def clr(self, *args):
        self.txtout.configure(state = NORMAL)
        self.txtout.delete(1.0, END)
        self.txtout.configure(state = DISABLED)

    def scrp(self, *args):
        self.word = self.poleinp.get()
        self.res = scripts.show_all(self.word)
        self.records = connect.pg_connect(self.res)
        self.txtout.configure(state = NORMAL)
        self.txtout.insert(1.0, self.records)
        self.txtout.configure(state = DISABLED)

root = Tk()
root.title("Обработчик")
root.geometry("1200x500")
obj = Handler_int()
root.mainloop()