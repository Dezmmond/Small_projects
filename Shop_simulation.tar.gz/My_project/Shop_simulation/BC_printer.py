#!-*- coding: utf-8 -*-
#!/usr/bin/python3

# This module exist just for drawing bar codes and save them to png format files.

# Этот модуль служит для рисования штрих кодов и сохранения их в формате png.

from BC_handler import BarCode_maker as bcm
from PIL import Image, ImageDraw
import time


class BC_prnt():
    def __init__(self, code, name):
        self.image = Image.new("RGB", (400, 245), (255, 255, 255))
        self.draw = ImageDraw.Draw(self.image)
        self.code = code
        self.name = name
        self.lines()

    def lines(self):
        nls = 50
        print(self.code)
        for i in self.code:
            if i == "0":
                nls += 4
            else:
                self.draw.line((nls, 5, nls, 240), fill="black", width=4)
                nls += 4

        del self.draw
        self.image.save("{}.png".format(self.name))


name_lst = []
def main(code, name):
    if code == None or not code[0].isdigit():
        return
    else:
        if name in name_lst:
            name = name + str(time.clock())
        else:
            name_lst.append(name)
        a = bcm(code)
        code = a.for_print()
        app = BC_prnt(code, name)
