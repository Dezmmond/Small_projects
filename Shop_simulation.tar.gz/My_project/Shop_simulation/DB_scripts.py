#!-*- coding: utf-8 -*-
#!/usr/bin/python3

# This module contains scripts.

# Этот модуль содержит скрипты.

import DB_connect
import BC_printer as bcp


def show_all(table_name):
    query = "SELECT * FROM" + " " + table_name
    result = DB_connect.pg_connect(query)
    return result


def make_bc(table_outpt):
    table_outpt = table_outpt.split('\n')
    for row in table_outpt:
        code = str(row[0:12])
        name = ""
        if len(row) > 13:
            for i in row[13:]:
                if i == ',':
                    break
                else:
                    name += i
            bcp.main(code, name)
        else:
            bcp.main(code, name)

