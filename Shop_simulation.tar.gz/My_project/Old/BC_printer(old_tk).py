from tkinter import Tk, Frame, BOTH, Canvas
from BC_handler import BarCode_maker as bcm
from PIL import Image, ImageDraw


class BC_prnt(Frame):
    def __init__(self, parent, code, name):
        Frame.__init__(self, parent, background="grey")
        self.parent = parent
        self.code = code
        self.name = name
        self.initUI()
        self.lines()

    def initUI(self):
        self.parent.title("BarCode for {}".format(self.name))
        self.pack(fill=BOTH, expand=1)

    def lines(self):
        canvas = Canvas(self)
        image1 = Image.new("RGB", (600, 400))
        draw = ImageDraw.Draw(image1)
        nls = 50
        print(self.code)
        for i in self.code:
            if i == "0":
                nls += 4
            else:
                canvas.create_line(nls, 5, nls, 240, width=4)
                nls += 4

        canvas.pack(expand=1)


def main(code, name):
    if not code[0].isdigit():
        return
    else:
        a = bcm(code)
        code = a.for_print()
        root = Tk()
        root.geometry("600x400")
        app = BC_prnt(root, code, name)
        #root.mainloop()
