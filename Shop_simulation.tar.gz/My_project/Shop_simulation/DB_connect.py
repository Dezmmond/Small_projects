#!-*- coding: utf-8 -*-
#!/usr/bin/python3

# This module is the connector to PostgreSQL data base. Also it formats output to the human-reliable text.

# Данный модуль является коннектором с базой данных PostgreSQL. Так же он преобразует вывод в удобочитаемый текст.

import psycopg2


def pg_connect(request):
    output_inf = ""
    conn = psycopg2.connect(dbname='shop',
                            user='postgres',
                            password='981114',
                            host='localhost')

    try:
        cursor = conn.cursor()
        cursor.execute(request)
        colnames = [desc[0] for desc in cursor.description]
        colnames = str(colnames)
        output_inf += colnames + '\n'

        for row in cursor:
            row = str(row)
            row = row.replace('(', '')
            row = row.replace(')', '')
            row = row.replace("'", '')
            if "datetime.date" in row:
                row = row.replace("datetime.date", "")
            output_inf += row + '\n'

        cursor.close()
        conn.close()

    except:
        warning = "Ошибка! Данная команда не поддерживается, либо введено неверное значение"
        return warning

    return output_inf

# SELECT * FROM Покупатели
